package it.uniroma3.bigdata.bold;

import java.io.File;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import it.uniroma3.bigdata.bold.mapper.MatrixCalculatorMapper;
import it.uniroma3.bigdata.bold.reducer.MatrixCalculatorReducer;

public class Main {


	public static void main(String[] args) throws Exception {		

		FileSystem fs = FileSystem.get(new Configuration());
		Path path = new Path(args[1]);

		if(!path.equals(null) || fs.getFileStatus(path).isDir()){
			fs.delete(new Path(args[1]), true);
		}

		
		for (FileStatus directory : fs.listStatus(new Path(args[0]))){ 

			if (directory.isDir()){
				
				String dirName = directory.getPath().getName();

				Job job = new Job(new Configuration(), "Matrix Calculator");

				job.setJarByClass(Main.class);

				job.setMapperClass(MatrixCalculatorMapper.class);
				job.setReducerClass(MatrixCalculatorReducer.class);

				FileInputFormat.addInputPath(job, new Path(args[0] + "/" + dirName));
				FileOutputFormat.setOutputPath(job, new Path(args[1] + "/" + dirName));

				job.setOutputKeyClass(Text.class);
				job.setOutputValueClass(Text.class);
				job.waitForCompletion(true);
			}
		}
	}
}