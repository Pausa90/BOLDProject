package it.uniroma3.bigdata.bold.reducer;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MatrixCalculatorReducer extends Reducer<Text, Text, Text, Text> {

	public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {

		String matrixTuple = "";
		for (Text windowFreq : values){
			matrixTuple += windowFreq + "\t";
		}
		context.write(key, new Text(matrixTuple));
	}
	
}
