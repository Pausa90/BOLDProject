package it.uniroma3.bigdata.bold.mapper;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

public class MatrixCalculatorMapper extends Mapper<LongWritable, Text, Text, Text> {

	private Text window_frequency = new Text();
	private Text id = new Text();

	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

		FileSplit fileSplit = (FileSplit)context.getInputSplit();
		String filename = fileSplit.getPath().getName();
		filename = this.cleanPath(filename);

		String line = value.toString();
		StringTokenizer tokenizer = new StringTokenizer(line);
		
		id.set(getIdInName(filename));
		String window = tokenizer.nextToken();
		Double frequency = this.calculateFrequency(filename, Integer.parseInt(tokenizer.nextToken()));
		window_frequency.set(window + "\t" + frequency);
		
		context.write(id, window_frequency);
	}
	
	private String cleanPath(String filename) {
		String[] splitted = filename.split("/");
		return splitted[splitted.length-1];
	}

	private String getIdInName(String fileName){
		String[] splitted = fileName.split("\\[");
		return splitted[0];
	}
	
	private String getParamInName(String fileName, String param){
		String[] splitted = fileName.split("\\[" + param + "=");
		splitted = splitted[1].split("]");
		return splitted[0];
	}
	
	private double calculateFrequency(String fileName, int occurrency){
		int k = Integer.parseInt(this.getParamInName(fileName, "k"));
		int length = Integer.parseInt(this.getParamInName(fileName, "length"));
		int incrementFactor = 100000;
		
		return incrementFactor* (((double)occurrency) / (length-k+1));
	}
	
}
